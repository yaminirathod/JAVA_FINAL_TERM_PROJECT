package com.amsvy.finalproject.beans;

import org.hibernate.validator.constraints.NotBlank;

public class Account {
	@NotBlank(message = "Data cannot be blank")
	private int accountid;
	private String name;
	private String emailid;
	private String transferemailid;
	private String transactiondate;

	public String getTransactiondate() {
		return transactiondate;
	}

	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getTransferemailid() {
		return transferemailid;
	}

	public void setTransferemailid(String transferemailid) {
		this.transferemailid = transferemailid;
	}

	private String address;
	private String accounttype;
	private double balance;
	private double depositamount;
	private double fromamount;
	private double toamount;

	public double getFromamount() {
		return fromamount;
	}

	public void setFromamount(double fromamount) {
		this.fromamount = fromamount;
	}

	public double getToamount() {
		return toamount;
	}

	public void setToamount(double toamount) {
		this.toamount = toamount;
	}

	public double getDepositamount() {
		return depositamount;
	}

	public void setDepositamount(double depositamount) {
		this.depositamount = depositamount;
	}

	private double withdrawamount;
	private int transferaccountid;
	private double transferamount;

	public int getTransferaccountid() {
		return transferaccountid;
	}

	public void setTransferaccountid(int transferaccountid) {
		this.transferaccountid = transferaccountid;
	}

	public double getTransferamount() {
		return transferamount;
	}

	public void setTransferamount(double transferamount) {
		this.transferamount = transferamount;
	}

	public double getWithdrawamount() {
		return withdrawamount;
	}

	public void setWithdrawamount(double withdrawamount) {
		this.withdrawamount = withdrawamount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	private String accountdate;
	private String accountexpdate;
	private int loginid;

	public int getAccountid() {
		return accountid;
	}

	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public String getAccountdate() {
		return accountdate;
	}

	public void setAccountdate(String accountdate) {
		this.accountdate = accountdate;
	}

	public String getAccountexpdate() {
		return accountexpdate;
	}

	public void setAccountexpdate(String accountexpdate) {
		this.accountexpdate = accountexpdate;
	}

	public int getLoginid() {
		return loginid;
	}

	public void setLoginid(int loginid) {
		this.loginid = loginid;
	}

}
