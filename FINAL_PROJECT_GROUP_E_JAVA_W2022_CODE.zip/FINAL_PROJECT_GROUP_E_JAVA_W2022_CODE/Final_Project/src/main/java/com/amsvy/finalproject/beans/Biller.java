package com.amsvy.finalproject.beans;

import org.hibernate.validator.constraints.NotBlank;

public class Biller {
	@NotBlank(message = "Data cannot be blank")
	private int billerid;
	private String name;
	private String address;
	private double totalamount;
	private double amounttopay;
	private int accountid;

	public int getBillerid() {
		return billerid;
	}

	public void setBillerid(int billerid) {
		this.billerid = billerid;
	}

	public double getTotalamount() {
		return totalamount;
	}

	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}

	public double getAmounttopay() {
		return amounttopay;
	}

	public void setAmounttopay(double amounttopay) {
		this.amounttopay = amounttopay;
	}

	public int getAccountid() {
		return accountid;
	}

	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
