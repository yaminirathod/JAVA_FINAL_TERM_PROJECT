package com.amsvy.finalproject.beans;

import org.hibernate.validator.constraints.NotBlank;

public class Login {
	@NotBlank(message = "Data cannot be blank")
	private String username;
	private String password;
	private String loginid;
	private boolean isadmin;

	public boolean isIsadmin() {
		return isadmin;
	}

	public void setIsadmin(boolean isadmin) {
		this.isadmin = isadmin;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoginid() {
		return loginid;
	}

	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

}
