package com.amsvy.finalproject.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.amsvy.finalproject.beans.Account;
import com.amsvy.finalproject.dao.AccountDao;

@Controller
public class AccountController {
	@Autowired
	AccountDao dao;// will inject dao from xml file

	/*
	 * It displays a form to input data, here "command" is a reserved request
	 * attribute which is used to display object data into form
	 */
	@RequestMapping("/accountform")
	public String accountform(Model m) {
		m.addAttribute("command", new Account());
		return "accountform";
	}

	// Convert Currency Layout
	@RequestMapping("/currencyform")
	public String currencyform(Model m) {
		m.addAttribute("command", new Account());
		return "currencyform";
	}

	// Convert Currency Layout Non Admin
	@RequestMapping("/currencyform_nonadmin")
	public String currencyform_nonadmin(Model m) {
		m.addAttribute("command", new Account());
		return "currencyform_nonadmin";
	}

	// Admin
	@RequestMapping(value = "/currencysave", method = RequestMethod.POST)
	public String currencysave(@ModelAttribute("account") Account account, ModelMap m) {
		double convertedCurrencyValue = dao.currencyconvert(account);
		m.addAttribute("message", convertedCurrencyValue);
		return "redirect:/viewcurrency";// will redirect to viewemp request mapping
	}

	// Non Admin
	@RequestMapping(value = "/currencysave_nonadmin", method = RequestMethod.POST)
	public String currencysave_nonadmin(@ModelAttribute("account") Account account, ModelMap m) {
		double convertedCurrencyValue = dao.currencyconvert(account);
		m.addAttribute("message", convertedCurrencyValue);
		return "redirect:/viewcurrency_nonadmin";// will redirect to viewemp request mapping
	}

	// Admin
	@RequestMapping("/viewcurrency")
	public String viewcurrency(Model m) {
		m.addAttribute("command", new Account());
		return "viewcurrency";
	}

	// Non Admin
	@RequestMapping("/viewcurrency_nonadmin")
	public String viewcurrency_nonadmin(Model m) {
		m.addAttribute("command", new Account());
		return "viewcurrency_nonadmin";
	}

	/*
	 * It saves object into database. The @ModelAttribute puts request data into
	 * model object. You need to mention RequestMethod.POST method because default
	 * request is GET
	 */
	@RequestMapping(value = "/accountsave", method = RequestMethod.POST)
	public String accountsave(@ModelAttribute("account") Account account) {
		dao.save1(account);
		return "redirect:/viewaccount";// will redirect to viewemp request mapping
	}

	/* It provides list of employees in model object */
	@RequestMapping("/viewaccount")
	public String viewmember(Model m) {
		List<Account> list = dao.getAccounts();
		m.addAttribute("list", list);
		return "viewaccount";
	}
	
	// View Logs Layout
	@RequestMapping("/viewlogs")
	public String viewlogs(Model m) {
		m.addAttribute("command", new Account());
		return "viewlogs";
	}
	
	// Biller Logs Layout
	@RequestMapping("/billerlogs")
	public String billerogs(Model m) {
		m.addAttribute("command", new Account());
		return "billerlogs";
	}

	// View Account Non Admin Layout (By Login)
	@RequestMapping("/viewaccount_nonadmin")
	public String viewaccount_nonadmin(Model m, @ModelAttribute("account") Account account) {
		List<Account> list = dao.getAccountsByLogin(account);
		m.addAttribute("list", list);
		return "viewaccount_nonadmin";
	}

	// View Account Check Layout
	@RequestMapping("/viewaccount_nonadmin_getloginid")
	public String viewaccount_nonadmin_getloginid(Model m) {
		m.addAttribute("command", new Account());
		return "viewaccount_nonadmin_getloginid";
	}

	// View Account CURD
	@RequestMapping(value = "/accountsavelc", method = RequestMethod.POST)
	public String accountsavelc(Model m, @ModelAttribute("account") Account account) {
		List<Account> list = dao.getAccountsByLogin(account);
		m.addAttribute("list", list);
		return "viewaccount_nonadmin";
	}

	/*
	 * It displays object data into form for the given id. The @PathVariable puts
	 * URL data into variable.
	 */
	@RequestMapping(value = "/editaccount/{accountid}")
	public String edit1(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accounteditform";
	}

	// Edit Account Non Admin Layout
	@RequestMapping(value = "/editaccount_nonadmin/{accountid}")
	public String editaccount_nonadmin(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accounteditform_nonadmin";
	}

	// Deposit View
	@RequestMapping(value = "/accountdeposit/{accountid}")
	public String edit4(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accountdepositform";
	}

	// Deposit View Non Admin
	@RequestMapping(value = "/accountdeposit_nonadmin/{accountid}")
	public String accountdeposit_nonadmin(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accountdepositform_nonadmin";
	}

	// Withdraw View
	@RequestMapping(value = "/accountwithdraw/{accountid}")
	public String edit2(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accountwithdrawform";
	}

	// Withdraw View Non Admin
	@RequestMapping(value = "/accountwithdraw_nonadmin/{accountid}")
	public String accountwithdraw_nonadmin(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accountwithdrawform_nonadmin";
	}

	// Transfer View
	@RequestMapping(value = "/accounttransfermoney/{accountid}")
	public String edit3(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accounttransfermoneyform";
	}

	// Transfer View Non Admin
	@RequestMapping(value = "/accounttransfermoney_nonadmin/{accountid}")
	public String accounttransfermoney_nonadmin(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "accounttransfermoneyform_nonadmin";
	}

	// Interact View
	@RequestMapping(value = "/interactmoney/{accountid}")
	public String interactmoney(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "interactmoneyform";
	}

	// Interact View Non Admin
	@RequestMapping(value = "/interactmoney_nonadmin/{accountid}")
	public String interactmoney_nonadmin(@PathVariable int accountid, Model m) {
		Account account = dao.getAccountById(accountid);
		m.addAttribute("command", account);
		return "interactmoneyform_nonadmin";
	}

	/* It updates model object. */
	@RequestMapping(value = "/editmsave", method = RequestMethod.POST)
	public String editsave1(@ModelAttribute("account") Account account) {
		dao.update1(account);
		return "redirect:/viewaccount";
	}

	// Edit Account CURD Non Admin
	@RequestMapping(value = "/editmsave_nonadmin", method = RequestMethod.POST)
	public String editmsave_nonadmin(@ModelAttribute("account") Account account) {
		dao.update1(account);
		return "redirect:/viewaccount_nonadmin_getloginid";
	}

	// Deposit curd
	@RequestMapping(value = "/dpeditmsave", method = RequestMethod.POST)
	public String editsave4(@ModelAttribute("account") Account account) {
		// dao.update2(account);
		if (dao.update5(account)) {
			return "redirect:/viewaccount";
		} else {
			return "redirect:/depositerror";
		}
	}

	// Deposit curd Non Admin
	@RequestMapping(value = "/dpeditmsave_nonadmin", method = RequestMethod.POST)
	public String dpeditmsave_nonadmin(@ModelAttribute("account") Account account) {
		// dao.update2(account);
		if (dao.update5(account)) {
			return "redirect:/viewaccount_nonadmin_getloginid";
		} else {
			return "redirect:/depositerror";
		}
	}

	/* It updates model object. */
	// Withdraw curd
	@RequestMapping(value = "/wdeditmsave", method = RequestMethod.POST)
	public String editsave2(@ModelAttribute("account") Account account) {
		// dao.update2(account);
		if (dao.update2(account)) {
			return "redirect:/viewaccount";
		} else {
			return "redirect:/withdrawerror";
		}
	}

	// Withdraw curd Non Admin
	@RequestMapping(value = "/wdeditmsave_nonadmin", method = RequestMethod.POST)
	public String wdeditmsave_nonadmin(@ModelAttribute("account") Account account) {
		// dao.update2(account);
		if (dao.update2(account)) {
			return "redirect:/viewaccount_nonadmin_getloginid";
		} else {
			return "redirect:/withdrawerror";
		}
	}

	// withdrawerror view
	@RequestMapping("/withdrawerror")
	public String withdrawerror(Model m) {
		List<Account> list = dao.getAccounts();
		m.addAttribute("list", list);
		return "withdrawerror";
	}

	// Transfer curd
	@RequestMapping(value = "/tmeditmsave", method = RequestMethod.POST)
	public String editsave3(@ModelAttribute("account") Account account) {
		if (dao.update3(account) && dao.update4(account)) {
			return "redirect:/viewaccount";
		} else {
			return "redirect:/withdrawerror";
		}
		// dao.update4(account);
	}

	// Transfer curd Non Admin
	@RequestMapping(value = "/tmeditmsave_nonadmin", method = RequestMethod.POST)
	public String tmeditmsave_nonadmin(@ModelAttribute("account") Account account) {
		if (dao.update3(account) && dao.update4(account)) {
			return "redirect:/viewaccount_nonadmin_getloginid";
		} else {
			return "redirect:/withdrawerror";
		}
		// dao.update4(account);
	}

	// Interact curd
	@RequestMapping(value = "/emeditmsave", method = RequestMethod.POST)
	public String emeditmsave(@ModelAttribute("account") Account account) {
		if (dao.update33(account) && dao.update44(account)) {
			return "redirect:/viewaccount";
		} else {
			return "redirect:/withdrawerror";
		}
		// dao.update4(account);
	}

	// Interact curd Non Admin
	@RequestMapping(value = "/emeditmsave_nonadmin", method = RequestMethod.POST)
	public String emeditmsave_nonadmin(@ModelAttribute("account") Account account) {
		if (dao.update33(account) && dao.update44(account)) {
			return "redirect:/viewaccount_nonadmin_getloginid";
		} else {
			return "redirect:/withdrawerror";
		}
		// dao.update4(account);
	}

	/* It deletes record for the given id in URL and redirects to /viewemp */
	@RequestMapping(value = "/deleteaccount/{accountid}", method = RequestMethod.GET)
	public String delete1(@PathVariable int accountid) {
		dao.delete1(accountid);
		return "redirect:/viewaccount";
	}

	// Delete Account Non Admin Layout
	@RequestMapping(value = "/deleteaccount_nonadmin/{accountid}", method = RequestMethod.GET)
	public String deleteaccount_nonadmin(@PathVariable int accountid) {
		dao.delete1(accountid);
		return "redirect:/viewaccount_nonadmin_getloginid";
	}
}