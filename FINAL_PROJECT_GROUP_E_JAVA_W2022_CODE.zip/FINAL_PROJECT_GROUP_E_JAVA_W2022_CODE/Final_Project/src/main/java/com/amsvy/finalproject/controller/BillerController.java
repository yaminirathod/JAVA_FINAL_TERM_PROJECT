package com.amsvy.finalproject.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.amsvy.finalproject.beans.Biller;
import com.amsvy.finalproject.dao.BillerDao;

@Controller
public class BillerController {
	@Autowired
	BillerDao dao;// will inject dao from xml file

	/*
	 * It displays a form to input data, here "command" is a reserved request
	 * attribute which is used to display object data into form
	 */
	@RequestMapping("/billerform")
	public String billerform(Model m) {
		m.addAttribute("command", new Biller());
		return "billerform";
	}

	/*
	 * It saves object into database. The @ModelAttribute puts request data into
	 * model object. You need to mention RequestMethod.POST method because default
	 * request is GET
	 */
	@RequestMapping(value = "/billersave", method = RequestMethod.POST)
	public String billersave(@ModelAttribute("biller") Biller biller) {
		dao.save1(biller);
		return "redirect:/viewbiller";// will redirect to viewemp request mapping
	}

	/* It provides list of employees in model object */
	@RequestMapping("/viewbiller")
	public String viewbiller(Model m) {
		List<Biller> list = dao.getBillers();
		m.addAttribute("list", list);
		return "viewbiller";
	}

	// View Biller Non Admin
	@RequestMapping("/viewbiller_nonadmin")
	public String viewbiller_nonadmin(Model m) {
		List<Biller> list = dao.getBillers();
		m.addAttribute("list", list);
		return "viewbiller_nonadmin";
	}

	/*
	 * It displays object data into form for the given id. The @PathVariable puts
	 * URL data into variable.
	 */
	@RequestMapping(value = "/editbiller/{billerid}")
	public String edit1(@PathVariable int billerid, Model m) {
		Biller biller = dao.getBillerById(billerid);
		m.addAttribute("command", biller);
		return "billereditform";
	}

	// Pay Biller Layout
	@RequestMapping(value = "/paybiller/{billerid}")
	public String paybiller(@PathVariable int billerid, Model m) {
		Biller biller = dao.getBillerById(billerid);
		m.addAttribute("command", biller);
		return "paybillerform";
	}

	// Pay Biller Non Admin Layout
	@RequestMapping(value = "/paybiller_nonadmin/{billerid}")
	public String paybiller_nonadmin(@PathVariable int billerid, Model m) {
		Biller biller = dao.getBillerById(billerid);
		m.addAttribute("command", biller);
		return "paybillerform_nonadmin";
	}

	/* It updates model object. */
	@RequestMapping(value = "/editpsave", method = RequestMethod.POST)
	public String editsave1(@ModelAttribute("biller") Biller biller) {
		dao.update1(biller);
		return "redirect:/viewbiller";
	}

	// Pay Biller CURD
	@RequestMapping(value = "/editbillsave", method = RequestMethod.POST)
	public String editbillsave(@ModelAttribute("biller") Biller biller) {
		dao.updatebilleraacount(biller);
		dao.updateaacountbalance(biller);
		return "redirect:/viewbiller";
	}

	// Pay Biller Non Admin CURD
	@RequestMapping(value = "/editbillsave_nonadmin", method = RequestMethod.POST)
	public String editbillsave_nonadmin(@ModelAttribute("biller") Biller biller) {
		dao.updatebilleraacount(biller);
		dao.updateaacountbalance(biller);
		return "redirect:/viewbiller_nonadmin";
	}

	/* It deletes record for the given id in URL and redirects to /viewemp */
	@RequestMapping(value = "/deletebiller/{billerid}", method = RequestMethod.GET)
	public String delete1(@PathVariable int billerid) {
		dao.delete1(billerid);
		return "redirect:/viewbiller";
	}
}