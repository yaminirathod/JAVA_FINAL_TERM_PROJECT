package com.amsvy.finalproject.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.support.DataAccessUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.amsvy.finalproject.beans.Account;

public class AccountDao {
	JdbcTemplate template;
	private Object jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int save1(Account p) {
		String sql = "insert into account(name,emailid,transferemailid,address,accounttype,balance,depositamount,withdrawamount,transferaccountid,transferamount,accountdate,accountexpdate,fromamount,toamount,loginid) "
				+ "values('" + p.getName() + "','" + p.getEmailid() + "','" + p.getTransferemailid() + "','"
				+ p.getAddress() + "','" + p.getAccounttype() + "'," + p.getBalance() + "," + p.getDepositamount() + ","
				+ p.getWithdrawamount() + "," + p.getTransferaccountid() + "," + p.getTransferamount() + ",'"
				+ p.getAccountdate() + "','" + p.getAccountexpdate() + "'," + p.getFromamount() + "," + p.getToamount()
				+ ", " + p.getLoginid() + ")";
		return template.update(sql);
	}

	public int update1(Account p) {
		String sql = "update account set name='" + p.getName() + "', emailid='" + p.getEmailid()
				+ "', transferemailid='" + p.getTransferemailid() + "', address='" + p.getAddress() + "',accounttype='"
				+ p.getAccounttype() + "',balance=" + p.getBalance() + ", depositamount=" + p.getDepositamount()
				+ " ,withdrawamount=" + p.getWithdrawamount() + ", transferaccountid=" + p.getTransferaccountid()
				+ ", transferamount=" + p.getTransferamount() + " ,accountdate='" + p.getAccountdate()
				+ "', accountexpdate='" + p.getAccountexpdate() + "', fromamount=" + p.getFromamount() + ", toamount="
				+ p.getToamount() + " , loginid=" + p.getLoginid() + " where accountid=" + p.getAccountid() + "";
		return template.update(sql);
	}

	// Deposit
	public boolean update5(Account p) {
		double newbalance = p.getBalance() + p.getDepositamount();
		if (newbalance >= 500) {
			String sql = "update account set balance=" + newbalance + " where accountid=" + p.getAccountid() + "";
			template.update(sql);
			return true;
		} else {
			return false;
		}
	}

	// Withdraw
	public boolean update2(Account p) {
		double newbalance = p.getBalance() - p.getWithdrawamount();
		if (newbalance >= 500) {
			String sql = "update account set balance=" + newbalance + " where accountid=" + p.getAccountid() + "";
			template.update(sql);
			return true;
		} else {
			return false;
		}
	}

	// Transfer
	public boolean update3(Account p) {
		double newbalance = p.getBalance() - p.getTransferamount();
		if (newbalance >= 500) {
			String sql = "update account set balance=" + newbalance + " where accountid=" + p.getAccountid() + "";
			int accountidvalue = p.getAccountid();
			double transferamountvalue = p.getTransferamount();
			int toaccountidvalue = p.getTransferaccountid();
			// java.util.Date sysdatevalue = new java.util.Date();

			java.util.Date date = Calendar.getInstance().getTime();
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String strDate = dateFormat.format(date);
			
			String transactionloginitial = "insert into transactionlog (transactiondate,accountid,toaccountid,transactionamount) values ('"
					+ strDate + "', " + accountidvalue + ", " + toaccountidvalue + "," + 0 + ")";
			template.update(transactionloginitial);

			String transactionlog = "insert into transactionlog (transactiondate,accountid,toaccountid,transactionamount) values ('"
					+ strDate + "', " + accountidvalue + ", " + toaccountidvalue + "," + transferamountvalue + ")";

			
			if(checkLastTransaction(p.getAccountid()))
			{			
				template.update(sql);
				template.update(transactionlog);
				return true;
			}
			else
			{
				return false;
			}

		} else {
			return false;
		}
	}

	public boolean checkLastTransaction(int accountid) {
		java.util.Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = dateFormat.format(date);
		
		String transactionamount = this.template.queryForObject("SELECT sum(transactionamount) FROM transactionlog "
				+ "WHERE accountid= ? and transactiondate = ?",
				new Object[] { accountid,strDate }, String.class);
		Double transactionamountvalue = Double.parseDouble(transactionamount);
		if(transactionamountvalue>=1000)
		{
			return false;
		}
		else
		{
			return true;
		}		
	}

	public String findBalanceById(int transferaccountid) {
		String blanacebyid = this.template.queryForObject("SELECT balance FROM account WHERE accountid= ?",
				new Object[] { transferaccountid }, String.class);
		return blanacebyid;
	}

	public boolean update4(Account p) {
		String balanceOFtransferacct = findBalanceById(p.getTransferaccountid());

		Double balanceOFtransferacctnew = Double.parseDouble(balanceOFtransferacct);

		double newbalancetrfacct = balanceOFtransferacctnew + p.getTransferamount();

		// String newbalancetrfacct = "select balance from account where
		// accountid="+p.getTransferaccountid()+"" + p.getTransferamount();
		String sql = "update account set balance=" + newbalancetrfacct + " where accountid=" + p.getTransferaccountid()
				+ "";
		template.update(sql);
		return true;
	}

	// Interact
	public boolean update33(Account p) {
		double newbalance = p.getBalance() - p.getTransferamount();
		if (newbalance >= 500) {
			String sql = "update account set balance=" + newbalance + " where accountid=" + p.getAccountid() + "";
			template.update(sql);
			return true;
		} else {
			return false;
		}
	}

	public String findBalanceByIdNew(String transferemailid) {
		String blanacebyemailid = this.template.queryForObject("SELECT balance FROM account WHERE emailid= ?",
				new Object[] { transferemailid }, String.class);
		return blanacebyemailid;
	}

	public boolean update44(Account p) {
		String balanceOFtransferacct = findBalanceByIdNew(p.getTransferemailid());

		Double balanceOFtransferacctnew = Double.parseDouble(balanceOFtransferacct);

		double newbalancetrfacct = balanceOFtransferacctnew + p.getTransferamount();

		// String newbalancetrfacct = "select balance from account where
		// accountid="+p.getTransferaccountid()+"" + p.getTransferamount();
		String sql = "update account set balance=" + newbalancetrfacct + " where emailid='" + p.getTransferemailid()
				+ "'";
		template.update(sql);
		return true;
	}

	public int delete1(int accountid) {
		String sql = "delete from account where accountid=" + accountid + "";
		return template.update(sql);
	}

	public Account getAccountById(int accountid) {
		String sql = "select * from account where accountid=?";
		return template.queryForObject(sql, new Object[] { accountid },
				new BeanPropertyRowMapper<Account>(Account.class));
	}

	public List<Account> getAccounts() {
		return template.query("select * from account", new RowMapper<Account>() {
			public Account mapRow(ResultSet rs, int row) throws SQLException {
				Account e = new Account();

				e.setAccountid(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setEmailid(rs.getString(3));
				e.setTransferemailid(rs.getString(4));
				e.setAddress(rs.getString(5));
				e.setAccounttype(rs.getString(6));
				e.setBalance(rs.getDouble(7));
				e.setDepositamount(rs.getDouble(8));
				e.setWithdrawamount(rs.getDouble(9));
				e.setTransferaccountid(rs.getInt(10));
				e.setTransferamount(rs.getDouble(11));
				e.setAccountdate(rs.getString(12));
				e.setAccountexpdate(rs.getString(13));
				e.setFromamount(rs.getDouble(14));
				e.setToamount(rs.getDouble(15));
				e.setLoginid(rs.getInt(16));
				return e;
			}
		});
	}

	public List<Account> getAccountsByLogin(Account p) {
		return template.query("select * from account where loginid=" + p.getLoginid() + "", new RowMapper<Account>() {
			public Account mapRow(ResultSet rs, int row) throws SQLException {
				Account e = new Account();

				e.setAccountid(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setEmailid(rs.getString(3));
				e.setTransferemailid(rs.getString(4));
				e.setAddress(rs.getString(5));
				e.setAccounttype(rs.getString(6));
				e.setBalance(rs.getDouble(7));
				e.setDepositamount(rs.getDouble(8));
				e.setWithdrawamount(rs.getDouble(9));
				e.setTransferaccountid(rs.getInt(10));
				e.setTransferamount(rs.getDouble(11));
				e.setAccountdate(rs.getString(12));
				e.setAccountexpdate(rs.getString(13));
				e.setFromamount(rs.getDouble(14));
				e.setToamount(rs.getDouble(15));
				e.setLoginid(rs.getInt(16));
				return e;
			}
		});
	}

	public void accountcheck(Account account) {
		// TODO Auto-generated method stub

	}

	public double currencyconvert(Account p) {
		// TODO Auto-generated method stub
		double convertedCurrency;
		double toamountselection = p.getToamount();
		if (toamountselection == 1) {
			convertedCurrency = 62.55 * p.getFromamount();
		} else if (toamountselection == 2) {
			convertedCurrency = 5.75 * p.getFromamount();
		} else if (toamountselection == 3) {
			convertedCurrency = 10.70 * p.getFromamount();
		} else if (toamountselection == 4) {
			convertedCurrency = 2.75 * p.getFromamount();
		} else if (toamountselection == 5) {
			convertedCurrency = 0.05 * p.getFromamount();
		} else if (toamountselection == 6) {
			convertedCurrency = 2.95 * p.getFromamount();
		} else if (toamountselection == 7) {
			convertedCurrency = 14.75 * p.getFromamount();
		} else {
			convertedCurrency = p.getFromamount();
		}
		return convertedCurrency;
	}
}
