package com.amsvy.finalproject.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.amsvy.finalproject.beans.Biller;

public class BillerDao {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int save1(Biller p) {
		String sql = "insert into biller(name,address,totalamount) values('" + p.getName() + "','" + p.getAddress()
				+ "'," + p.getTotalamount() + ")";
		return template.update(sql);
	}

	public int update1(Biller p) {
		String sql = "update biller set name='" + p.getName() + "', address='" + p.getAddress() + "',totalamount="
				+ p.getTotalamount() + " where billerid=" + p.getBillerid() + "";
		return template.update(sql);
	}

	public int delete1(int billerid) {
		String sql = "delete from biller where billerid=" + billerid + "";
		return template.update(sql);
	}

	public Biller getBillerById(int billerid) {
		String sql = "select * from biller where billerid=?";
		return template.queryForObject(sql, new Object[] { billerid }, new BeanPropertyRowMapper<Biller>(Biller.class));
	}

	public List<Biller> getBillers() {
		return template.query("select * from biller", new RowMapper<Biller>() {
			public Biller mapRow(ResultSet rs, int row) throws SQLException {
				Biller e = new Biller();
				e.setBillerid(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setAddress(rs.getString(3));
				e.setTotalamount(rs.getDouble(4));

				return e;
			}
		});
	}

//bill payment
	public int updatebilleraacount(Biller p) {
		double newbalance = p.getTotalamount() + p.getAmounttopay();
		String sql = "update biller set totalamount=" + newbalance + " where billerid=" + p.getBillerid() + "";
		return template.update(sql);
	}

//deduct paid bill from respective account
	public int updateaacountbalance(Biller p) {
		String amountofpayer = findBalanceById(p.getAccountid());

		Double amountofpayervalue = Double.parseDouble(amountofpayer);

		double newaccbalance = amountofpayervalue - p.getAmounttopay();
		String sql = "update account set balance=" + newaccbalance + " where accountid=" + p.getAccountid() + "";
		
		java.util.Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String strDate = dateFormat.format(date);
		int billeridvalue = p.getBillerid();
		int accountidvalue = p.getAccountid();

		String billerlog = "insert into billerlog (transactiondate,billerid,accountid) values ('"
				+ strDate + "', " + billeridvalue + ", " + accountidvalue +")";
		template.update(billerlog);
		
		return template.update(sql);
	}

	private String findBalanceById(int accountid) {
		String blanacebyid = this.template.queryForObject("SELECT balance FROM account WHERE accountid= ?",
				new Object[] { accountid }, String.class);
		return blanacebyid;
	}
}