package com.amsvy.finalproject.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.amsvy.finalproject.beans.Customer;

public class CustomerDao {

	JdbcTemplate template;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int save(Customer p) {
		String sql = "insert into customer (name,address,type,regdate,expdate,loginid) " + "values('" + p.getName()
				+ "','" + p.getAddress() + "','" + p.getType() + "','" + p.getRegdate() + "','" + p.getExpdate() + "','"
				+ p.getLoginid() + "')";
		return template.update(sql);
	}

	public int update(Customer p) {
		String sql = "update customer set name='" + p.getName() + "', address='" + p.getAddress() + "',type='"
				+ p.getType() + "',regdate='" + p.getRegdate() + "',expdate='" + p.getExpdate() + "',loginid='"
				+ p.getLoginid() + "' where customerid=" + p.getCustomerid() + "";
		return template.update(sql);
	}

	public int delete(int customerid) {
		String sql = "delete from customer where customerid=" + customerid + "";
		return template.update(sql);
	}

	public Customer getCustomerById(int customerid) {
		String sql = "select * from customer where customerid=?";
		return template.queryForObject(sql, new Object[] { customerid },
				new BeanPropertyRowMapper<Customer>(Customer.class));
	}

	public List<Customer> getCustomers() {
		return template.query("select * from customer", new RowMapper<Customer>() {
			public Customer mapRow(ResultSet rs, int row) throws SQLException {
				Customer e = new Customer();
				e.setCustomerid(rs.getString(1));
				e.setName(rs.getString(2));
				e.setAddress(rs.getString(3));
				e.setType(rs.getString(4));
				e.setRegdate(rs.getString(5));
				e.setExpdate(rs.getString(6));
				e.setLoginid(rs.getString(7));

				return e;
			}
		});
	}

}