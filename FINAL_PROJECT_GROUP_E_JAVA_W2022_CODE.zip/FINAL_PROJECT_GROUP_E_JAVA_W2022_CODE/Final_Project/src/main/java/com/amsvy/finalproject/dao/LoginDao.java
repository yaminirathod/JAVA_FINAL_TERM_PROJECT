package com.amsvy.finalproject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.amsvy.finalproject.beans.Login;

public class LoginDao {

	JdbcTemplate template;
	private Object namedParameterJdbcTemplate;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public int save1(Login p) {
		String sql = "insert into login(username,password,isadmin) values('" + p.getUsername() + "','" + p.getPassword()
				+ "'," + p.isIsadmin() + ")";
		return template.update(sql);
	}

	@SuppressWarnings("null")
	public boolean loginchecking(Login p) throws SQLException {
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Final", "root", "root");

		// String sql="select * from login where username = '"+p.getUsername()+"' and
		// password = '"+p.getPassword()+"'";
		String sql = "select * from login where username = '" + p.getUsername() + "' and password = '" + p.getPassword()
				+ "'";

		PreparedStatement ps = connection.prepareStatement("select * from login where username = '" + p.getUsername()
				+ "' and password = '" + p.getPassword() + "'");

		ResultSet rs = ps.executeQuery();
		boolean status = rs.next();
		return status;
	}

// admin check
	@SuppressWarnings("null")
	public boolean adminchecking(Login p) throws SQLException {
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Final", "root", "root");
		String adminUsername = "admin";
		// String sql="select * from login where username = '"+p.getUsername()+"' and
		// password = '"+p.getPassword()+"'";
		String sql = "select * from login where username = '" + adminUsername + "' and password = '" + p.getPassword()
				+ "'";

		PreparedStatement ps = connection.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();
		boolean status = rs.next();
		return status;
	}

	public List<Login> getUsers() {
		return template.query("select * from login", new RowMapper<Login>() {
			public Login mapRow(ResultSet rs, int row) throws SQLException {
				Login e = new Login();
				e.setLoginid(rs.getString(1));
				e.setUsername(rs.getString(2));
				e.setPassword(rs.getString(3));
				e.setIsadmin(rs.getBoolean(4));

				return e;
			}
		});
	}

	public int update1(Login p) {
		String sql = "update login set username='" + p.getUsername() + "', password='" + p.getPassword()
				+ "' where loginid=" + p.getLoginid() + "";
		return template.update(sql);
	}

	public int delete1(int loginid) {
		String sql = "delete from login where loginid=" + loginid + "";
		return template.update(sql);
	}

	public Login getUserById(int loginid) {
		String sql = "select * from login where loginid=?";
		return template.queryForObject(sql, new Object[] { loginid }, new BeanPropertyRowMapper<Login>(Login.class));
	}
}